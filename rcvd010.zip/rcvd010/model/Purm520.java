package com.gfc.rcvd010.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * The persistent class for the "purm520" database table.
 * 
 */
@Entity
@Table(name = "purm520")
@NamedQuery(name = "Purm520.findAll", query = "SELECT p FROM Purm520 p")
//@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Purm520 implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private Purm520PK id;

	@Column(name = "accum_qty")
	private BigDecimal accumQty;

	@Temporal(TemporalType.DATE)
	@Column(name = "conf_good")
	private Date confGood;

	@Temporal(TemporalType.DATE)
	@Column(name = "create_date")
	private Date createDate;

	@Column(name = "create_id")
	private String createId;

	@Column(name = "ct_no")
	private BigDecimal ctNo;

	@Column(name = "currency")
	private String currency;

	@Temporal(TemporalType.DATE)
	@Column(name = "current_date")
	private Date currentDate;

	@Column(name = "delv_seq")
	private BigDecimal delvSeq;

	@Column(name = "elev_no")
	private BigDecimal elevNo;

	@Column(name = "end_code")
	private String endCode;

	@Column(name = "foreign_amt")
	private BigDecimal foreignAmt;

	@Column(name = "item")
	private String item;

	@Column(name = "item_no")
	private String itemNo;

	@Column(name = "lc_code")
	private String lcCode;

	@Column(name = "modify_no")
	private String modifyNo;

	@Column(name = "obj_code")
	private String objCode;

	@Column(name = "oder_amt")
	private BigDecimal oderAmt;

	@Temporal(TemporalType.DATE)
	@Column(name = "oder_date")
	private Date oderDate;

	@Column(name = "oder_qty")
	private BigDecimal oderQty;

	@Column(name = "pay_cnd")
	private String payCnd;

	@Column(name = "pntr_no")
	private String pntrNo;

	@Column(name = "po_empno")
	private BigDecimal poEmpno;

	@Temporal(TemporalType.DATE)
	@Column(name = "pre_good")
	private Date preGood;

	@Column(name = "price_base")
	private String priceBase;

	@Column(name = "proc_code")
	private String procCode;

	@Column(name = "prt_time")
	private BigDecimal prtTime;

	@Temporal(TemporalType.DATE)
	@Column(name = "pur_date")
	private Date purDate;

	@Column(name = "pur_empno")
	private BigDecimal purEmpno;

	@Column(name = "pur_qty")
	private BigDecimal purQty;

	@Column(name = "recv_proctr")
	private String recvProctr;

	@Column(name = "recv_qty")
	private BigDecimal recvQty;

	@Column(name = "remk_1")
	private String remk1;

	@Column(name = "remk_2")
	private String remk2;

	@Column(name = "remk_3")
	private String remk3;

	@Column(name = "schr_code")
	private String schrCode;

	@Column(name = "ship_via")
	private String shipVia;

	@Column(name = "stus_code")
	private String stusCode;

	@Column(name = "tot_cost")
	private BigDecimal totCost;

	@Column(name = "unit_price")
	private BigDecimal unitPrice;

	@Temporal(TemporalType.DATE)
	@Column(name = "update_date")
	private Date updateDate;

	@Column(name = "update_id")
	private String updateId;

	@Column(name = "vndr_code")
	private BigDecimal vndrCode;

//	@JsonIgnoreProperties({ "purm520" })
//	@NotFound(action = NotFoundAction.IGNORE)
	@JsonManagedReference
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "purm520")
	Purm030 purm030;

	public Purm520() {
	}

	public Purm520PK getId() {
		return this.id;
	}

	public void setId(Purm520PK id) {
		this.id = id;
	}

	public BigDecimal getAccumQty() {
		return this.accumQty;
	}

	public void setAccumQty(BigDecimal accumQty) {
		this.accumQty = accumQty;
	}

	public Date getConfGood() {
		return this.confGood;
	}

	public void setConfGood(Date confGood) {
		this.confGood = confGood;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateId() {
		return this.createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public BigDecimal getCtNo() {
		return this.ctNo;
	}

	public void setCtNo(BigDecimal ctNo) {
		this.ctNo = ctNo;
	}

	public String getCurrency() {
		return this.currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Date getCurrentDate() {
		return this.currentDate;
	}

	public void setCurrentDate(Date currentDate) {
		this.currentDate = currentDate;
	}

	public BigDecimal getDelvSeq() {
		return this.delvSeq;
	}

	public void setDelvSeq(BigDecimal delvSeq) {
		this.delvSeq = delvSeq;
	}

	public BigDecimal getElevNo() {
		return this.elevNo;
	}

	public void setElevNo(BigDecimal elevNo) {
		this.elevNo = elevNo;
	}

	public String getEndCode() {
		return this.endCode;
	}

	public void setEndCode(String endCode) {
		this.endCode = endCode;
	}

	public BigDecimal getForeignAmt() {
		return this.foreignAmt;
	}

	public void setForeignAmt(BigDecimal foreignAmt) {
		this.foreignAmt = foreignAmt;
	}

	public String getItem() {
		return this.item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getItemNo() {
		return this.itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public String getLcCode() {
		return this.lcCode;
	}

	public void setLcCode(String lcCode) {
		this.lcCode = lcCode;
	}

	public String getModifyNo() {
		return this.modifyNo;
	}

	public void setModifyNo(String modifyNo) {
		this.modifyNo = modifyNo;
	}

	public String getObjCode() {
		return this.objCode;
	}

	public void setObjCode(String objCode) {
		this.objCode = objCode;
	}

	public BigDecimal getOderAmt() {
		return this.oderAmt;
	}

	public void setOderAmt(BigDecimal oderAmt) {
		this.oderAmt = oderAmt;
	}

	public Date getOderDate() {
		return this.oderDate;
	}

	public void setOderDate(Date oderDate) {
		this.oderDate = oderDate;
	}

	public BigDecimal getOderQty() {
		return this.oderQty;
	}

	public void setOderQty(BigDecimal oderQty) {
		this.oderQty = oderQty;
	}

	public String getPayCnd() {
		return this.payCnd;
	}

	public void setPayCnd(String payCnd) {
		this.payCnd = payCnd;
	}

	public String getPntrNo() {
		return this.pntrNo;
	}

	public void setPntrNo(String pntrNo) {
		this.pntrNo = pntrNo;
	}

	public BigDecimal getPoEmpno() {
		return this.poEmpno;
	}

	public void setPoEmpno(BigDecimal poEmpno) {
		this.poEmpno = poEmpno;
	}

	public Date getPreGood() {
		return this.preGood;
	}

	public void setPreGood(Date preGood) {
		this.preGood = preGood;
	}

	public String getPriceBase() {
		return this.priceBase;
	}

	public void setPriceBase(String priceBase) {
		this.priceBase = priceBase;
	}

	public String getProcCode() {
		return this.procCode;
	}

	public void setProcCode(String procCode) {
		this.procCode = procCode;
	}

	public BigDecimal getPrtTime() {
		return this.prtTime;
	}

	public void setPrtTime(BigDecimal prtTime) {
		this.prtTime = prtTime;
	}

	public Date getPurDate() {
		return this.purDate;
	}

	public void setPurDate(Date purDate) {
		this.purDate = purDate;
	}

	public BigDecimal getPurEmpno() {
		return this.purEmpno;
	}

	public void setPurEmpno(BigDecimal purEmpno) {
		this.purEmpno = purEmpno;
	}

	public BigDecimal getPurQty() {
		return this.purQty;
	}

	public void setPurQty(BigDecimal purQty) {
		this.purQty = purQty;
	}

	public String getRecvProctr() {
		return this.recvProctr;
	}

	public void setRecvProctr(String recvProctr) {
		this.recvProctr = recvProctr;
	}

	public BigDecimal getRecvQty() {
		return this.recvQty;
	}

	public void setRecvQty(BigDecimal recvQty) {
		this.recvQty = recvQty;
	}

	public String getRemk1() {
		return this.remk1;
	}

	public void setRemk1(String remk1) {
		this.remk1 = remk1;
	}

	public String getRemk2() {
		return this.remk2;
	}

	public void setRemk2(String remk2) {
		this.remk2 = remk2;
	}

	public String getRemk3() {
		return this.remk3;
	}

	public void setRemk3(String remk3) {
		this.remk3 = remk3;
	}

	public String getSchrCode() {
		return this.schrCode;
	}

	public void setSchrCode(String schrCode) {
		this.schrCode = schrCode;
	}

	public String getShipVia() {
		return this.shipVia;
	}

	public void setShipVia(String shipVia) {
		this.shipVia = shipVia;
	}

	public String getStusCode() {
		return this.stusCode;
	}

	public void setStusCode(String stusCode) {
		this.stusCode = stusCode;
	}

	public BigDecimal getTotCost() {
		return this.totCost;
	}

	public void setTotCost(BigDecimal totCost) {
		this.totCost = totCost;
	}

	public BigDecimal getUnitPrice() {
		return this.unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public BigDecimal getVndrCode() {
		return this.vndrCode;
	}

	public void setVndrCode(BigDecimal vndrCode) {
		this.vndrCode = vndrCode;
	}

	public Purm030 getPurm030() {
		return this.purm030;
	}

	public void setPurm030(Purm030 purm030) {
		this.purm030 = purm030;
	}

}