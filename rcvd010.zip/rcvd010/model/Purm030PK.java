package com.gfc.rcvd010.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the "purm030" database table.
 * 
 */
@Embeddable
public class Purm030PK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "pro_ctr")
	private String proCtr;

	@Column(name = "wrhs_no")
	private String wrhsNo;

	@Column(name = "tx_code")
	private String txCode;

	@Column(name = "recv_yyyymm")
	private long recvYyyymm;

	@Column(name = "recv_no")
	private long recvNo;

	@Column(name = "recv_item")
	private long recvItem;

	public Purm030PK() {
	}

	public String getProCtr() {
		return this.proCtr;
	}

	public void setProCtr(String proCtr) {
		this.proCtr = proCtr;
	}

	public String getWrhsNo() {
		return this.wrhsNo;
	}

	public void setWrhsNo(String wrhsNo) {
		this.wrhsNo = wrhsNo;
	}

	public String getTxCode() {
		return this.txCode;
	}

	public void setTxCode(String txCode) {
		this.txCode = txCode;
	}

	public long getRecvYyyymm() {
		return this.recvYyyymm;
	}

	public void setRecvYyyymm(long recvYyyymm) {
		this.recvYyyymm = recvYyyymm;
	}

	public long getRecvNo() {
		return this.recvNo;
	}

	public void setRecvNo(long recvNo) {
		this.recvNo = recvNo;
	}

	public long getRecvItem() {
		return this.recvItem;
	}

	public void setRecvItem(long recvItem) {
		this.recvItem = recvItem;
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof Purm030PK)) {
			return false;
		}
		Purm030PK castOther = (Purm030PK) other;
		return this.proCtr.equals(castOther.proCtr) && this.wrhsNo.equals(castOther.wrhsNo)
				&& this.txCode.equals(castOther.txCode) && (this.recvYyyymm == castOther.recvYyyymm)
				&& (this.recvNo == castOther.recvNo) && (this.recvItem == castOther.recvItem);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.proCtr.hashCode();
		hash = hash * prime + this.wrhsNo.hashCode();
		hash = hash * prime + this.txCode.hashCode();
		hash = hash * prime + ((int) (this.recvYyyymm ^ (this.recvYyyymm >>> 32)));
		hash = hash * prime + ((int) (this.recvNo ^ (this.recvNo >>> 32)));
		hash = hash * prime + ((int) (this.recvItem ^ (this.recvItem >>> 32)));

		return hash;
	}
}