package com.gfc.rcvd010.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 * The persistent class for the "purm030" database table.
 * 
 */
@Entity
@Table(name = "purm030")
@NamedQuery(name = "Purm030.findAll", query = "SELECT p FROM Purm030 p")
//@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Purm030 implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private Purm030PK id;

	@Column(name = "acnt_no1")
	private String acntNo1;

	@Column(name = "acnt_no2")
	private String acntNo2;

	@Column(name = "bad_qty")
	private BigDecimal badQty;

	@Temporal(TemporalType.DATE)
	@Column(name = "create_date")
	private Date createDate;

	@Column(name = "create_id")
	private String createId;

	@Column(name = "delv_seq")
	private BigDecimal delvSeq;

	@Column(name = "good_qty")
	private BigDecimal goodQty;

	@Column(name = "in_price")
	private BigDecimal inPrice;

	@Column(name = "in_qty")
	private BigDecimal inQty;

	@Column(name = "inv_amt")
	private BigDecimal invAmt;

	@Temporal(TemporalType.DATE)
	@Column(name = "inv_date")
	private Date invDate;

	@Column(name = "inv_hd")
	private String invHd;

	@Column(name = "inv_no")
	private BigDecimal invNo;

	@Column(name = "inv_tax")
	private BigDecimal invTax;

	@Column(name = "item_no")
	private String itemNo;

	@Column(name = "mtl_cost")
	private BigDecimal mtlCost;

	@Column(name = "ok_code")
	private String okCode;

	@Temporal(TemporalType.DATE)
	@Column(name = "pay_date")
	private Date payDate;

	@Column(name = "pay_days")
	private BigDecimal payDays;

	@Column(name = "pay_vouitem")
	private BigDecimal payVouitem;

	@Column(name = "pay_vouno")
	private BigDecimal payVouno;

	@Column(name = "pay_vouyyyymm")
	private BigDecimal payVouyyyymm;

	@Column(name = "pcs_no")
	private String pcsNo;

	@Column(name = "proc_code")
	private String procCode;

	@Column(name = "pur_item")
	private long purItem;

	@Column(name = "pur_no")
	private long purNo;

	@Column(name = "pur_proctr")
	private String purProctr;

	@Column(name = "pur_wrhsno")
	private String purWrhsno;

	@Column(name = "pur_yyyymm")
	private long purYyyymm;

	@Temporal(TemporalType.DATE)
	@Column(name = "qcin_date")
	private Date qcinDate;

	@Column(name = "qual_brok")
	private BigDecimal qualBrok;

	@Column(name = "qual_code")
	private String qualCode;

	@Temporal(TemporalType.DATE)
	@Column(name = "qual_date")
	private Date qualDate;

	@Column(name = "qual_empno")
	private BigDecimal qualEmpno;

	@Column(name = "qual_qty")
	private BigDecimal qualQty;

	@Temporal(TemporalType.DATE)
	@Column(name = "recv_date")
	private Date recvDate;

	@Column(name = "recv_empno")
	private BigDecimal recvEmpno;

	@Column(name = "recv_qty")
	private BigDecimal recvQty;

	@Column(name = "schr_code")
	private String schrCode;

	@Column(name = "short_qty")
	private BigDecimal shortQty;

	@Column(name = "unify_no")
	private String unifyNo;

	@Temporal(TemporalType.DATE)
	@Column(name = "update_date")
	private Date updateDate;

	@Column(name = "update_id")
	private String updateId;

	@Column(name = "vou_item")
	private BigDecimal vouItem;

	@Column(name = "vou_lin")
	private String vouLin;

	@Column(name = "vou_no")
	private BigDecimal vouNo;

	@Column(name = "vou_yyyymm")
	private BigDecimal vouYyyymm;

	@Column(name = "write_item")
	private BigDecimal writeItem;

	@Column(name = "write_no")
	private BigDecimal writeNo;

	@Column(name = "write_yyyymm")
	private BigDecimal writeYyyymm;

//	@JsonIgnoreProperties({ "purm030" })
//	@NotFound(action = NotFoundAction.IGNORE)
	@JsonBackReference
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "pur_proctr", insertable = false, updatable = false),
			@JoinColumn(name = "pur_item", insertable = false, updatable = false),
			@JoinColumn(name = "pur_no", insertable = false, updatable = false),
			@JoinColumn(name = "pur_yyyymm", insertable = false, updatable = false),
			@JoinColumn(name = "pur_wrhsno", insertable = false, updatable = false),
			@JoinColumn(name = "wrhs_no", insertable = false, updatable = false) })
	Purm520 purm520;

	public Purm030() {
	}

	public Purm030PK getId() {
		return this.id;
	}

	public void setId(Purm030PK id) {
		this.id = id;
	}

	public String getAcntNo1() {
		return this.acntNo1;
	}

	public void setAcntNo1(String acntNo1) {
		this.acntNo1 = acntNo1;
	}

	public String getAcntNo2() {
		return this.acntNo2;
	}

	public void setAcntNo2(String acntNo2) {
		this.acntNo2 = acntNo2;
	}

	public BigDecimal getBadQty() {
		return this.badQty;
	}

	public void setBadQty(BigDecimal badQty) {
		this.badQty = badQty;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getCreateId() {
		return this.createId;
	}

	public void setCreateId(String createId) {
		this.createId = createId;
	}

	public BigDecimal getDelvSeq() {
		return this.delvSeq;
	}

	public void setDelvSeq(BigDecimal delvSeq) {
		this.delvSeq = delvSeq;
	}

	public BigDecimal getGoodQty() {
		return this.goodQty;
	}

	public void setGoodQty(BigDecimal goodQty) {
		this.goodQty = goodQty;
	}

	public BigDecimal getInPrice() {
		return this.inPrice;
	}

	public void setInPrice(BigDecimal inPrice) {
		this.inPrice = inPrice;
	}

	public BigDecimal getInQty() {
		return this.inQty;
	}

	public void setInQty(BigDecimal inQty) {
		this.inQty = inQty;
	}

	public BigDecimal getInvAmt() {
		return this.invAmt;
	}

	public void setInvAmt(BigDecimal invAmt) {
		this.invAmt = invAmt;
	}

	public Date getInvDate() {
		return this.invDate;
	}

	public void setInvDate(Date invDate) {
		this.invDate = invDate;
	}

	public String getInvHd() {
		return this.invHd;
	}

	public void setInvHd(String invHd) {
		this.invHd = invHd;
	}

	public BigDecimal getInvNo() {
		return this.invNo;
	}

	public void setInvNo(BigDecimal invNo) {
		this.invNo = invNo;
	}

	public BigDecimal getInvTax() {
		return this.invTax;
	}

	public void setInvTax(BigDecimal invTax) {
		this.invTax = invTax;
	}

	public String getItemNo() {
		return this.itemNo;
	}

	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}

	public BigDecimal getMtlCost() {
		return this.mtlCost;
	}

	public void setMtlCost(BigDecimal mtlCost) {
		this.mtlCost = mtlCost;
	}

	public String getOkCode() {
		return this.okCode;
	}

	public void setOkCode(String okCode) {
		this.okCode = okCode;
	}

	public Date getPayDate() {
		return this.payDate;
	}

	public void setPayDate(Date payDate) {
		this.payDate = payDate;
	}

	public BigDecimal getPayDays() {
		return this.payDays;
	}

	public void setPayDays(BigDecimal payDays) {
		this.payDays = payDays;
	}

	public BigDecimal getPayVouitem() {
		return this.payVouitem;
	}

	public void setPayVouitem(BigDecimal payVouitem) {
		this.payVouitem = payVouitem;
	}

	public BigDecimal getPayVouno() {
		return this.payVouno;
	}

	public void setPayVouno(BigDecimal payVouno) {
		this.payVouno = payVouno;
	}

	public BigDecimal getPayVouyyyymm() {
		return this.payVouyyyymm;
	}

	public void setPayVouyyyymm(BigDecimal payVouyyyymm) {
		this.payVouyyyymm = payVouyyyymm;
	}

	public String getPcsNo() {
		return this.pcsNo;
	}

	public void setPcsNo(String pcsNo) {
		this.pcsNo = pcsNo;
	}

	public String getProcCode() {
		return this.procCode;
	}

	public void setProcCode(String procCode) {
		this.procCode = procCode;
	}

	public long getPurItem() {
		return this.purItem;
	}

	public void setPurItem(long purItem) {
		this.purItem = purItem;
	}

	public long getPurNo() {
		return this.purNo;
	}

	public void setPurNo(long purNo) {
		this.purNo = purNo;
	}

	public String getPurProctr() {
		return this.purProctr;
	}

	public void setPurProctr(String purProctr) {
		this.purProctr = purProctr;
	}

	public String getPurWrhsno() {
		return this.purWrhsno;
	}

	public void setPurWrhsno(String purWrhsno) {
		this.purWrhsno = purWrhsno;
	}

	public long getPurYyyymm() {
		return this.purYyyymm;
	}

	public void setPurYyyymm(long purYyyymm) {
		this.purYyyymm = purYyyymm;
	}

	public Date getQcinDate() {
		return this.qcinDate;
	}

	public void setQcinDate(Date qcinDate) {
		this.qcinDate = qcinDate;
	}

	public BigDecimal getQualBrok() {
		return this.qualBrok;
	}

	public void setQualBrok(BigDecimal qualBrok) {
		this.qualBrok = qualBrok;
	}

	public String getQualCode() {
		return this.qualCode;
	}

	public void setQualCode(String qualCode) {
		this.qualCode = qualCode;
	}

	public Date getQualDate() {
		return this.qualDate;
	}

	public void setQualDate(Date qualDate) {
		this.qualDate = qualDate;
	}

	public BigDecimal getQualEmpno() {
		return this.qualEmpno;
	}

	public void setQualEmpno(BigDecimal qualEmpno) {
		this.qualEmpno = qualEmpno;
	}

	public BigDecimal getQualQty() {
		return this.qualQty;
	}

	public void setQualQty(BigDecimal qualQty) {
		this.qualQty = qualQty;
	}

	public Date getRecvDate() {
		return this.recvDate;
	}

	public void setRecvDate(Date recvDate) {
		this.recvDate = recvDate;
	}

	public BigDecimal getRecvEmpno() {
		return this.recvEmpno;
	}

	public void setRecvEmpno(BigDecimal recvEmpno) {
		this.recvEmpno = recvEmpno;
	}

	public BigDecimal getRecvQty() {
		return this.recvQty;
	}

	public void setRecvQty(BigDecimal recvQty) {
		this.recvQty = recvQty;
	}

	public String getSchrCode() {
		return this.schrCode;
	}

	public void setSchrCode(String schrCode) {
		this.schrCode = schrCode;
	}

	public BigDecimal getShortQty() {
		return this.shortQty;
	}

	public void setShortQty(BigDecimal shortQty) {
		this.shortQty = shortQty;
	}

	public String getUnifyNo() {
		return this.unifyNo;
	}

	public void setUnifyNo(String unifyNo) {
		this.unifyNo = unifyNo;
	}

	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateId() {
		return this.updateId;
	}

	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}

	public BigDecimal getVouItem() {
		return this.vouItem;
	}

	public void setVouItem(BigDecimal vouItem) {
		this.vouItem = vouItem;
	}

	public String getVouLin() {
		return this.vouLin;
	}

	public void setVouLin(String vouLin) {
		this.vouLin = vouLin;
	}

	public BigDecimal getVouNo() {
		return this.vouNo;
	}

	public void setVouNo(BigDecimal vouNo) {
		this.vouNo = vouNo;
	}

	public BigDecimal getVouYyyymm() {
		return this.vouYyyymm;
	}

	public void setVouYyyymm(BigDecimal vouYyyymm) {
		this.vouYyyymm = vouYyyymm;
	}

	public BigDecimal getWriteItem() {
		return this.writeItem;
	}

	public void setWriteItem(BigDecimal writeItem) {
		this.writeItem = writeItem;
	}

	public BigDecimal getWriteNo() {
		return this.writeNo;
	}

	public void setWriteNo(BigDecimal writeNo) {
		this.writeNo = writeNo;
	}

	public BigDecimal getWriteYyyymm() {
		return this.writeYyyymm;
	}

	public void setWriteYyyymm(BigDecimal writeYyyymm) {
		this.writeYyyymm = writeYyyymm;
	}

	public Purm520 getPurm520() {
		return this.purm520;
	}

}