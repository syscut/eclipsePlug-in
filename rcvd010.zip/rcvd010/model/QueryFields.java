package com.gfc.rcvd010.model;

public class QueryFields {

}
