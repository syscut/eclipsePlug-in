package com.gfc.rcvd010.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the "purm520" database table.
 * 
 */
@Embeddable
public class Purm520PK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "pro_ctr")
	private String proCtr;

	@Column(name = "wrhs_no")
	private String wrhsNo;

	@Column(name = "tx_code")
	private String txCode;

	@Column(name = "pur_yyyymm")
	private long purYyyymm;

	@Column(name = "pur_no")
	private long purNo;

	@Column(name = "pur_item")
	private long purItem;

	public Purm520PK() {
	}

	public String getProCtr() {
		return this.proCtr;
	}

	public void setProCtr(String proCtr) {
		this.proCtr = proCtr;
	}

	public String getWrhsNo() {
		return this.wrhsNo;
	}

	public void setWrhsNo(String wrhsNo) {
		this.wrhsNo = wrhsNo;
	}

	public String getTxCode() {
		return this.txCode;
	}

	public void setTxCode(String txCode) {
		this.txCode = txCode;
	}

	public long getPurYyyymm() {
		return this.purYyyymm;
	}

	public void setPurYyyymm(long purYyyymm) {
		this.purYyyymm = purYyyymm;
	}

	public long getPurNo() {
		return this.purNo;
	}

	public void setPurNo(long purNo) {
		this.purNo = purNo;
	}

	public long getPurItem() {
		return this.purItem;
	}

	public void setPurItem(long purItem) {
		this.purItem = purItem;
	}

	@Override
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof Purm520PK)) {
			return false;
		}
		Purm520PK castOther = (Purm520PK) other;
		return this.proCtr.equals(castOther.proCtr) && this.wrhsNo.equals(castOther.wrhsNo)
				&& this.txCode.equals(castOther.txCode) && (this.purYyyymm == castOther.purYyyymm)
				&& (this.purNo == castOther.purNo) && (this.purItem == castOther.purItem);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.proCtr.hashCode();
		hash = hash * prime + this.wrhsNo.hashCode();
		hash = hash * prime + this.txCode.hashCode();
		hash = hash * prime + ((int) (this.purYyyymm ^ (this.purYyyymm >>> 32)));
		hash = hash * prime + ((int) (this.purNo ^ (this.purNo >>> 32)));
		hash = hash * prime + ((int) (this.purItem ^ (this.purItem >>> 32)));

		return hash;
	}
}