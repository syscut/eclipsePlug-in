package com.gfc.rcvd010.filter;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.filter.Filter;
import ch.qos.logback.core.spi.FilterReply;

public class StartingInfoFilter extends Filter<ILoggingEvent> {
	@Override
	public FilterReply decide(ILoggingEvent event) {
		if (event.getLevel().levelStr == "INFO" && event.getMarker() == null
				&& (event.getLoggerName() == "com.gfc.rcvd010.Rcvd010Application"
						|| event.getLoggerName() == "com.zaxxer.hikari.HikariDataSource")) {
			return FilterReply.ACCEPT;
		} else {
			return FilterReply.DENY;
		}
	}
}