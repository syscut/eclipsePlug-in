package com.gfc.rcvd010.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.gfc.rcvd010.model.Purm030;
import com.gfc.rcvd010.model.Purm030PK;
import com.gfc.rcvd010.model.Purm520;
import com.gfc.rcvd010.model.Purm520PK;
import com.gfc.rcvd010.repository.Purm030Repository;
import com.gfc.rcvd010.repository.Purm520Repository;
import com.gfc.rcvd010.service.TestService;

@CrossOrigin("*")
@RestController
public class Controller {
	@Autowired
	private Purm030Repository purm030Repository;
	@Autowired
	private Purm520Repository purm520Repository;

	@Autowired
	private TestService testService;

	@GetMapping(path = "/apiTest")
	public int apiTest() {
		return HttpServletResponse.SC_OK;
	}

	@PostMapping(path = "/find")
	public Optional<Purm520> test(@RequestBody Purm030PK purm030) {
		Optional<Purm030> oPurm030 = purm030Repository.findById(purm030);
		Purm520PK purm520pk = new Purm520PK();
		purm520pk.setProCtr(oPurm030.get().getPurProctr());
		purm520pk.setPurItem(oPurm030.get().getPurItem());
		purm520pk.setPurNo(oPurm030.get().getPurNo());
		purm520pk.setPurYyyymm(oPurm030.get().getPurYyyymm());
		purm520pk.setTxCode(oPurm030.get().getPurWrhsno());
		purm520pk.setWrhsNo(oPurm030.get().getId().getWrhsNo());
		return purm520Repository.findById(purm520pk);
	}

//	@PostMapping(path = "/findfrom520")
//	public Optional<Purm520> test2(@RequestBody Purm520PK purm520) {
//		return purm520Repository.findById(purm520);
//	}

	@PostMapping(path = "/findByProCtr")
	public List<Optional<Purm520>> test3(@RequestBody Purm520PK purm520) {
		return purm520Repository.findAllByIdProCtrAndIdWrhsNoAndIdTxCodeAndIdPurYyyymmAndIdPurNo(purm520.getProCtr(),
				purm520.getWrhsNo(), purm520.getTxCode(), purm520.getPurYyyymm(), purm520.getPurNo());
	}

	@PostMapping(path = "/findfrom520")
	public List<Purm520> test2(@RequestBody Purm520 purm520) {
		return testService.read(purm520);
	}

}
