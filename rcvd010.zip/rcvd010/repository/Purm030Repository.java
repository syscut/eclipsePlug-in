package com.gfc.rcvd010.repository;

import org.springframework.data.repository.CrudRepository;

import com.gfc.rcvd010.model.Purm030;
import com.gfc.rcvd010.model.Purm030PK;

public interface Purm030Repository extends CrudRepository<Purm030, Purm030PK> {

}
