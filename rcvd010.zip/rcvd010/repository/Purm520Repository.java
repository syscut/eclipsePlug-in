package com.gfc.rcvd010.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.gfc.rcvd010.model.Purm520;
import com.gfc.rcvd010.model.Purm520PK;

public interface Purm520Repository extends CrudRepository<Purm520, Purm520PK> {

	List<Optional<Purm520>> findAllByIdProCtrAndIdWrhsNoAndIdTxCodeAndIdPurYyyymmAndIdPurNo(String idproCtr,
			String wrhsNo, String txCode, long purYyyymm, long purNo);
}
