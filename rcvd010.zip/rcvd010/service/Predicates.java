package com.gfc.rcvd010.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;

public class Predicates<T> {
	public Predicate[] where(CriteriaBuilder cb, Root<T> root, JSONObject json) throws JSONException {
		List<Predicate> predicates = new ArrayList<Predicate>();
		if (!Objects.isNull(json.get("id"))) {

		}
		return predicates.toArray(new Predicate[] {});
	}
}
