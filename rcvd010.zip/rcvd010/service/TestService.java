package com.gfc.rcvd010.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gfc.rcvd010.model.Purm030;
import com.gfc.rcvd010.model.Purm520;

@Service
@Transactional
public class TestService {

	@PersistenceContext
	private EntityManager em;

	public List<Purm520> read(Purm520 purm520) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
		CriteriaQuery<Purm520> cq = cb.createQuery(Purm520.class);
		Root<Purm520> root = cq.from(Purm520.class);
		Join<Purm520, Purm030> join = root.join("purm030", JoinType.LEFT);

		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(cb.equal(root.get("id").get("proCtr"), purm520.getId().getProCtr()));
		predicates.add(cb.equal(root.get("id").get("wrhsNo"), purm520.getId().getWrhsNo()));
		predicates.add(cb.equal(root.get("id").get("txCode"), purm520.getId().getTxCode()));
		predicates.add(cb.equal(root.get("id").get("purYyyymm"), purm520.getId().getPurYyyymm()));
		predicates.add(cb.equal(root.get("id").get("purNo"), purm520.getId().getPurNo()));
		predicates.add(cb.equal(root.get("id").get("purItem"), purm520.getId().getPurItem()));
		cq.where(predicates.toArray(new Predicate[] {}));

		return em.createQuery(cq).setMaxResults(10).getResultList();

	}

	@SuppressWarnings("unchecked")
	public List<Purm520> read() {
		List<Purm520> res = em.createNativeQuery(
				"select * from purm520 a, purm030 b where a.wrhs_no = b.wrhs_no and a.tx_code = b.pur_wrhsno"
						+ " and a.pur_yyyymm = b.pur_yyyymm and a.pur_no = b.pur_no and a.pur_item = b.pur_item"
						+ " and a.pro_ctr = '9' and a.wrhs_no = '9' and a.tx_code = 'RA'"
						+ " and a.pur_yyyymm = 201111 and a.pur_no = 1 and a.pur_item = 1 and b.pro_ctr = '9'"
						+ " and b.wrhs_no = '9' and b.tx_code = 'CA' and b.recv_yyyymm = 201111 and b.recv_no = 4031"
						+ " and b.recv_item = 1",
				Purm520.class).setMaxResults(300).getResultList();
		return res;
	}
}
